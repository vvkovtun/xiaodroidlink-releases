#!/usr/bin/env bash
# XiaoDroidLink Helper — Linux and macOS.
# Gives XiaoDroidLink two extra permissions over a USB cable (adb), or takes them back:
#   PROJECT_MEDIA          — locking the phone no longer stops music and the car connection
#   WRITE_SECURE_SETTINGS  — screen goes almost black while the phone lies still; a stalled
#                            car control service restarts itself
# Nothing else on the phone is changed. Official adb is downloaded from Google if missing.

PKG="salon.lifestyle.xiaodroidlink"
MIN_CODE=172   # 8.26 — first version where both extras work
DIR="$(cd "$(dirname "$0")" && pwd)"
TOOLS="$DIR/xiaodroidlink-adb"
ADB=""
L=en

# ---------- texts ----------
t() {
  case "$L:$1" in
    en:title) echo "XiaoDroidLink Helper";;
    ru:title) echo "Помощник XiaoDroidLink";;
    uk:title) echo "Помічник XiaoDroidLink";;

    en:get_adb) echo "Downloading Android tools from Google (about 7 MB)...";;
    ru:get_adb) echo "Скачиваю инструменты Android с сайта Google (около 7 МБ)...";;
    uk:get_adb) echo "Завантажую інструменти Android із сайту Google (близько 7 МБ)...";;
    en:no_net) echo "Could not download. Check the internet connection and run the helper again.";;
    ru:no_net) echo "Не удалось скачать. Проверьте интернет и запустите помощник ещё раз.";;
    uk:no_net) echo "Не вдалося завантажити. Перевірте інтернет і запустіть помічник ще раз.";;

    en:connect) echo "Connect the phone with a USB cable. Waiting for the phone...";;
    ru:connect) echo "Подключите телефон USB-кабелем. Жду телефон...";;
    uk:connect) echo "Підключіть телефон USB-кабелем. Чекаю на телефон...";;
    en:no_phone) printf '%s\n' "The phone is not visible. Check:" "  1. The cable is plugged in (some cables only charge — try another)." "  2. On the phone, \"USB debugging\" is ON (see the instruction)." "  3. If the phone asks what to do with USB, choose \"File transfer\".";;
    ru:no_phone) printf '%s\n' "Телефон не виден. Проверьте:" "  1. Кабель подключён (некоторые кабели только заряжают — попробуйте другой)." "  2. На телефоне включена «Отладка по USB» (см. инструкцию)." "  3. Если телефон спрашивает, что делать с USB, выберите «Передача файлов».";;
    uk:no_phone) printf '%s\n' "Телефон не видно. Перевірте:" "  1. Кабель підключено (деякі кабелі лише заряджають — спробуйте інший)." "  2. На телефоні ввімкнено «Налагодження по USB» (див. інструкцію)." "  3. Якщо телефон питає, що робити з USB, виберіть «Передавання файлів».";;
    en:allow) echo ">>> Look at the phone: a window \"Allow USB debugging?\" — tick \"Always allow\" and tap \"Allow\".";;
    ru:allow) echo ">>> Посмотрите на телефон: окно «Разрешить отладку по USB?» — отметьте «Всегда разрешать» и нажмите «Разрешить».";;
    uk:allow) echo ">>> Подивіться на телефон: вікно «Дозволити налагодження по USB?» — позначте «Завжди дозволяти» і натисніть «Дозволити».";;
    en:many) echo "More than one phone is connected. Leave only one and run the helper again.";;
    ru:many) echo "Подключено больше одного телефона. Оставьте один и запустите помощник ещё раз.";;
    uk:many) echo "Підключено більше одного телефона. Залиште один і запустіть помічник ще раз.";;
    en:found) echo "Phone found:";;
    ru:found) echo "Телефон найден:";;
    uk:found) echo "Телефон знайдено:";;

    en:no_app) echo "XiaoDroidLink is not installed on this phone. Install it from Google Play and run the helper again.";;
    ru:no_app) echo "На этом телефоне нет XiaoDroidLink. Установите его из Google Play и запустите помощник ещё раз.";;
    uk:no_app) echo "На цьому телефоні немає XiaoDroidLink. Встановіть його з Google Play і запустіть помічник ще раз.";;
    en:old_app) echo "XiaoDroidLink is too old. Update it in Google Play (version 8.26 or newer) and run the helper again.";;
    ru:old_app) echo "XiaoDroidLink устарел. Обновите его в Google Play (версия 8.26 или новее) и запустите помощник ещё раз.";;
    uk:old_app) echo "XiaoDroidLink застарів. Оновіть його в Google Play (версія 8.26 або новіша) і запустіть помічник ще раз.";;

    en:menu) printf '%s\n' "" "What to do?" "  1 — Turn ON the extra features" "  2 — Turn everything OFF (back to normal)" "  3 — Only switch off the dark screen (if something went wrong)" "  0 — Exit";;
    ru:menu) printf '%s\n' "" "Что сделать?" "  1 — ВКЛЮЧИТЬ дополнительные функции" "  2 — ВЫКЛЮЧИТЬ всё (вернуть как было)" "  3 — Только убрать затемнение экрана (если что-то пошло не так)" "  0 — Выход";;
    uk:menu) printf '%s\n' "" "Що зробити?" "  1 — УВІМКНУТИ додаткові функції" "  2 — ВИМКНУТИ все (повернути як було)" "  3 — Лише прибрати затемнення екрана (якщо щось пішло не так)" "  0 — Вихід";;
    en:choose) printf "Type a number and press Enter: ";;
    ru:choose) printf "Введите цифру и нажмите Enter: ";;
    uk:choose) printf "Введіть цифру й натисніть Enter: ";;

    en:on_ok) printf '%s\n' "Done ✓ Now XiaoDroidLink:" "  • keeps music and the car connection when you lock the phone;" "  • no longer asks \"Allow screen casting\";" "  • makes the phone screen almost black while it lies still (normal again in your hand);" "  • restarts its car control service by itself if Android stops it.";;
    ru:on_ok) printf '%s\n' "Готово ✓ Теперь XiaoDroidLink:" "  • не теряет музыку и связь с машиной, когда вы блокируете телефон;" "  • больше не спрашивает «Разрешить трансляцию»;" "  • делает экран телефона почти чёрным, пока он лежит (в руке — обычный);" "  • сам перезапускает службу управления с машины, если Android её остановил.";;
    uk:on_ok) printf '%s\n' "Готово ✓ Тепер XiaoDroidLink:" "  • не втрачає музику і зв'язок з машиною, коли ви блокуєте телефон;" "  • більше не питає «Дозволити трансляцію»;" "  • робить екран телефона майже чорним, поки він лежить (у руці — звичайний);" "  • сам перезапускає службу керування з машини, якщо Android її зупинив.";;
    en:on_half) echo "Partly done: locking no longer stops the stream, but the dark screen and service restart are not available on this phone.";;
    ru:on_half) echo "Сделано частично: блокировка больше не останавливает трансляцию, но затемнение и перезапуск службы на этом телефоне недоступны.";;
    uk:on_half) echo "Зроблено частково: блокування більше не зупиняє трансляцію, але затемнення й перезапуск служби на цьому телефоні недоступні.";;
    en:xiaomi) printf '%s\n' "Xiaomi / Redmi / POCO: also turn on \"USB debugging (Security settings)\"" "in Developer options. It needs you to sign in to the Mi account ON THE PHONE (Settings → Mi Account; not the car account) and to have a SIM card in the phone. Then run the helper again.";;
    ru:xiaomi) printf '%s\n' "Xiaomi / Redmi / POCO: включите ещё «Отладка по USB (настройки безопасности)»" "в «Для разработчиков». Нужно войти в Mi-аккаунт НА ТЕЛЕФОНЕ (Настройки → Mi-аккаунт; аккаунт машины не нужен) и вставить SIM-карту. Потом запустите помощник ещё раз.";;
    uk:xiaomi) printf '%s\n' "Xiaomi / Redmi / POCO: увімкніть ще «Налагодження по USB (налаштування безпеки)»" "у «Для розробників». Потрібно увійти в Mi-акаунт НА ТЕЛЕФОНІ (Налаштування → Mi-акаунт; акаунт машини не потрібен) і вставити SIM-картку. Потім запустіть помічник ще раз.";;
    en:failed) echo "Did not work. Send this text to the XiaoDroidLink support (button \"Something not working?\" in the app):";;
    ru:failed) echo "Не получилось. Пришлите этот текст в поддержку XiaoDroidLink (кнопка «Что-то не работает?» в приложении):";;
    uk:failed) echo "Не вийшло. Надішліть цей текст у підтримку XiaoDroidLink (кнопка «Щось не працює?» у застосунку):";;

    en:off_ok) echo "Done ✓ Everything is back to normal. XiaoDroidLink works as before.";;
    ru:off_ok) echo "Готово ✓ Всё как было. XiaoDroidLink работает как раньше.";;
    uk:off_ok) echo "Готово ✓ Усе як було. XiaoDroidLink працює як раніше.";;
    en:dim_ok) echo "Done ✓ The dark screen is switched off.";;
    ru:dim_ok) echo "Готово ✓ Затемнение экрана выключено.";;
    uk:dim_ok) echo "Готово ✓ Затемнення екрана вимкнено.";;
    en:unplug) echo "You can unplug the cable.";;
    ru:unplug) echo "Кабель можно отключить.";;
    uk:unplug) echo "Кабель можна від'єднати.";;
    en:close) printf "Press Enter to close.";;
    ru:close) printf "Нажмите Enter, чтобы закрыть.";;
    uk:close) printf "Натисніть Enter, щоб закрити.";;
  esac
}

finish() { echo; t close; read -r _; exit "${1:-0}"; }

# ---------- language ----------
echo "XiaoDroidLink Helper"
echo "  1 — English"
echo "  2 — Русский"
echo "  3 — Українська"
printf "Language / Язык / Мова [1-3]: "
read -r answer
case "$answer" in 2) L=ru;; 3) L=uk;; *) L=en;; esac
echo; echo "=== $(t title) ==="; echo

# ---------- adb ----------
if command -v adb >/dev/null 2>&1; then
  ADB="$(command -v adb)"
elif [ -x "$TOOLS/platform-tools/adb" ]; then
  ADB="$TOOLS/platform-tools/adb"
else
  case "$(uname -s)" in Darwin) os=darwin;; *) os=linux;; esac
  t get_adb
  mkdir -p "$TOOLS"
  if ! curl -fsSL -o "$TOOLS/tools.zip" "https://dl.google.com/android/repository/platform-tools-latest-$os.zip" \
     || ! unzip -qo "$TOOLS/tools.zip" -d "$TOOLS"; then
    t no_net; finish 1
  fi
  rm -f "$TOOLS/tools.zip"
  ADB="$TOOLS/platform-tools/adb"
fi
"$ADB" start-server >/dev/null 2>&1

# ---------- phone ----------
t connect
asked=0
for i in $(seq 1 90); do
  list="$("$ADB" devices | tail -n +2 | grep -v '^$')"
  count=$(printf '%s\n' "$list" | grep -c .)
  if [ "$count" -gt 1 ]; then t many; finish 1; fi
  case "$list" in
    *unauthorized*) [ $asked = 0 ] && { t allow; asked=1; };;
    *device*) break;;
  esac
  sleep 2
done
case "$list" in *device*) ;; *) echo; t no_phone; finish 1;; esac
model="$("$ADB" shell getprop ro.product.model </dev/null | tr -d '\r')"
brand="$("$ADB" shell getprop ro.product.brand </dev/null | tr -d '\r')"
echo "$(t found) $brand $model"

sh_() { "$ADB" shell "$@" </dev/null 2>&1 | tr -d '\r'; }

if ! sh_ pm list packages "$PKG" | grep -qx "package:$PKG"; then t no_app; finish 1; fi
code="$(sh_ dumpsys package "$PKG" | grep -m1 -o 'versionCode=[0-9]*' | cut -d= -f2)"

# ---------- menu ----------
t menu; t choose; read -r choice; echo
case "$choice" in
  1)
    if [ "${code:-0}" -lt "$MIN_CODE" ]; then t old_app; finish 1; fi
    out1="$(sh_ appops set "$PKG" PROJECT_MEDIA allow)"
    out2="$(sh_ pm grant "$PKG" android.permission.WRITE_SECURE_SETTINGS)"
    ok1=0; sh_ appops get "$PKG" PROJECT_MEDIA | grep -q "allow" && ok1=1
    ok2=0; sh_ dumpsys package "$PKG" | grep -q "WRITE_SECURE_SETTINGS: granted=true" && ok2=1
    if [ $ok1 = 1 ] && [ $ok2 = 1 ]; then t on_ok; t unplug; finish 0; fi
    if [ $ok1 = 1 ]; then
      t on_half
      case "$(printf '%s' "$brand" | tr 'A-Z' 'a-z')" in xiaomi|redmi|poco) echo; t xiaomi;; esac
      finish 1
    fi
    t failed; echo "$brand $model / $code"; echo "$out1"; echo "$out2"; finish 1;;
  2)
    sh_ settings put secure reduce_bright_colors_activated 0 >/dev/null
    sh_ appops set "$PKG" PROJECT_MEDIA ignore >/dev/null
    sh_ pm revoke "$PKG" android.permission.WRITE_SECURE_SETTINGS >/dev/null
    t off_ok; t unplug; finish 0;;
  3)
    sh_ settings put secure reduce_bright_colors_activated 0 >/dev/null
    t dim_ok; t unplug; finish 0;;
  *) finish 0;;
esac
