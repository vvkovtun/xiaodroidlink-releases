@echo off
rem XiaoDroidLink Helper - Windows.
rem Gives XiaoDroidLink two extra permissions over a USB cable (adb), or takes them back:
rem   PROJECT_MEDIA          - locking the phone no longer stops music and the car connection
rem   WRITE_SECURE_SETTINGS  - screen goes almost black while the phone lies still; a stalled
rem                            car control service restarts itself
rem Nothing else on the phone is changed. Official adb is downloaded from Google if missing.
chcp 65001 >nul
setlocal EnableDelayedExpansion
set "PKG=salon.lifestyle.xiaodroidlink"
set "MIN_CODE=172"
set "DIR=%~dp0"
set "TOOLS=%DIR%xiaodroidlink-adb"

echo XiaoDroidLink Helper
echo   1 - English
echo   2 - Русский
echo   3 - Українська
set "LANGSEL="
set /p "LANGSEL=Language / Язык / Мова [1-3]: "
if "%LANGSEL%"=="2" goto ru
if "%LANGSEL%"=="3" goto uk

:en
set "T_TITLE=XiaoDroidLink Helper"
set "T_GETADB=Downloading Android tools from Google (about 7 MB)..."
set "T_NONET=Could not download. Check the internet connection and run the helper again."
set "T_CONNECT=Connect the phone with a USB cable. Waiting for the phone..."
set "T_NOPHONE1=The phone is not visible. Check:"
set "T_NOPHONE2=  1. The cable is plugged in (some cables only charge - try another)."
set "T_NOPHONE3=  2. On the phone, "USB debugging" is ON (see the instruction)."
set "T_NOPHONE4=  3. If the phone asks what to do with USB, choose "File transfer"."
set "T_ALLOW=>>> Look at the phone: a window "Allow USB debugging?" - tick "Always allow" and tap "Allow"."
set "T_MANY=More than one phone is connected. Leave only one and run the helper again."
set "T_FOUND=Phone found:"
set "T_NOAPP=XiaoDroidLink is not installed on this phone. Install it from Google Play and run the helper again."
set "T_OLDAPP=XiaoDroidLink is too old. Update it in Google Play (version 8.26 or newer) and run the helper again."
set "T_MENU0=What to do?"
set "T_MENU1=  1 - Turn ON the extra features"
set "T_MENU2=  2 - Turn everything OFF (back to normal)"
set "T_MENU3=  3 - Only switch off the dark screen (if something went wrong)"
set "T_MENU4=  0 - Exit"
set "T_CHOOSE=Type a number and press Enter: "
set "T_ON0=Done ✓ Now XiaoDroidLink:"
set "T_ON1=  • keeps music and the car connection when you lock the phone;"
set "T_ON2=  • no longer asks "Allow screen casting";"
set "T_ON3=  • makes the phone screen almost black while it lies still (normal again in your hand);"
set "T_ON4=  • restarts its car control service by itself if Android stops it."
set "T_HALF=Partly done: locking no longer stops the stream, but the dark screen and service restart are not available on this phone."
set "T_XIAOMI1=Xiaomi / Redmi / POCO: also turn on "USB debugging (Security settings)""
set "T_XIAOMI2=in Developer options (needs a Mi account and a SIM card), then run the helper again."
set "T_FAILED=Did not work. Send this text to the XiaoDroidLink support (button "Something not working?" in the app):"
set "T_OFF=Done ✓ Everything is back to normal. XiaoDroidLink works as before."
set "T_DIM=Done ✓ The dark screen is switched off."
set "T_UNPLUG=You can unplug the cable."
set "T_CLOSE=Press any key to close."
goto start

:ru
set "T_TITLE=Помощник XiaoDroidLink"
set "T_GETADB=Скачиваю инструменты Android с сайта Google (около 7 МБ)..."
set "T_NONET=Не удалось скачать. Проверьте интернет и запустите помощник ещё раз."
set "T_CONNECT=Подключите телефон USB-кабелем. Жду телефон..."
set "T_NOPHONE1=Телефон не виден. Проверьте:"
set "T_NOPHONE2=  1. Кабель подключён (некоторые кабели только заряжают - попробуйте другой)."
set "T_NOPHONE3=  2. На телефоне включена «Отладка по USB» (см. инструкцию)."
set "T_NOPHONE4=  3. Если телефон спрашивает, что делать с USB, выберите «Передача файлов»."
set "T_ALLOW=>>> Посмотрите на телефон: окно «Разрешить отладку по USB?» - отметьте «Всегда разрешать» и нажмите «Разрешить»."
set "T_MANY=Подключено больше одного телефона. Оставьте один и запустите помощник ещё раз."
set "T_FOUND=Телефон найден:"
set "T_NOAPP=На этом телефоне нет XiaoDroidLink. Установите его из Google Play и запустите помощник ещё раз."
set "T_OLDAPP=XiaoDroidLink устарел. Обновите его в Google Play (версия 8.26 или новее) и запустите помощник ещё раз."
set "T_MENU0=Что сделать?"
set "T_MENU1=  1 - ВКЛЮЧИТЬ дополнительные функции"
set "T_MENU2=  2 - ВЫКЛЮЧИТЬ всё (вернуть как было)"
set "T_MENU3=  3 - Только убрать затемнение экрана (если что-то пошло не так)"
set "T_MENU4=  0 - Выход"
set "T_CHOOSE=Введите цифру и нажмите Enter: "
set "T_ON0=Готово ✓ Теперь XiaoDroidLink:"
set "T_ON1=  • не теряет музыку и связь с машиной, когда вы блокируете телефон;"
set "T_ON2=  • больше не спрашивает «Разрешить трансляцию»;"
set "T_ON3=  • делает экран телефона почти чёрным, пока он лежит (в руке - обычный);"
set "T_ON4=  • сам перезапускает службу управления с машины, если Android её остановил."
set "T_HALF=Сделано частично: блокировка больше не останавливает трансляцию, но затемнение и перезапуск службы на этом телефоне недоступны."
set "T_XIAOMI1=Xiaomi / Redmi / POCO: включите ещё «Отладка по USB (настройки безопасности)»"
set "T_XIAOMI2=в «Для разработчиков» (нужны Mi-аккаунт и SIM-карта) и запустите помощник ещё раз."
set "T_FAILED=Не получилось. Пришлите этот текст в поддержку XiaoDroidLink (кнопка «Что-то не работает?» в приложении):"
set "T_OFF=Готово ✓ Всё как было. XiaoDroidLink работает как раньше."
set "T_DIM=Готово ✓ Затемнение экрана выключено."
set "T_UNPLUG=Кабель можно отключить."
set "T_CLOSE=Нажмите любую клавишу, чтобы закрыть."
goto start

:uk
set "T_TITLE=Помічник XiaoDroidLink"
set "T_GETADB=Завантажую інструменти Android із сайту Google (близько 7 МБ)..."
set "T_NONET=Не вдалося завантажити. Перевірте інтернет і запустіть помічник ще раз."
set "T_CONNECT=Підключіть телефон USB-кабелем. Чекаю на телефон..."
set "T_NOPHONE1=Телефон не видно. Перевірте:"
set "T_NOPHONE2=  1. Кабель підключено (деякі кабелі лише заряджають - спробуйте інший)."
set "T_NOPHONE3=  2. На телефоні ввімкнено «Налагодження по USB» (див. інструкцію)."
set "T_NOPHONE4=  3. Якщо телефон питає, що робити з USB, виберіть «Передавання файлів»."
set "T_ALLOW=>>> Подивіться на телефон: вікно «Дозволити налагодження по USB?» - позначте «Завжди дозволяти» і натисніть «Дозволити»."
set "T_MANY=Підключено більше одного телефона. Залиште один і запустіть помічник ще раз."
set "T_FOUND=Телефон знайдено:"
set "T_NOAPP=На цьому телефоні немає XiaoDroidLink. Встановіть його з Google Play і запустіть помічник ще раз."
set "T_OLDAPP=XiaoDroidLink застарів. Оновіть його в Google Play (версія 8.26 або новіша) і запустіть помічник ще раз."
set "T_MENU0=Що зробити?"
set "T_MENU1=  1 - УВІМКНУТИ додаткові функції"
set "T_MENU2=  2 - ВИМКНУТИ все (повернути як було)"
set "T_MENU3=  3 - Лише прибрати затемнення екрана (якщо щось пішло не так)"
set "T_MENU4=  0 - Вихід"
set "T_CHOOSE=Введіть цифру й натисніть Enter: "
set "T_ON0=Готово ✓ Тепер XiaoDroidLink:"
set "T_ON1=  • не втрачає музику і зв'язок з машиною, коли ви блокуєте телефон;"
set "T_ON2=  • більше не питає «Дозволити трансляцію»;"
set "T_ON3=  • робить екран телефона майже чорним, поки він лежить (у руці - звичайний);"
set "T_ON4=  • сам перезапускає службу керування з машини, якщо Android її зупинив."
set "T_HALF=Зроблено частково: блокування більше не зупиняє трансляцію, але затемнення й перезапуск служби на цьому телефоні недоступні."
set "T_XIAOMI1=Xiaomi / Redmi / POCO: увімкніть ще «Налагодження по USB (налаштування безпеки)»"
set "T_XIAOMI2=у «Для розробників» (потрібні Mi-акаунт і SIM-картка) і запустіть помічник ще раз."
set "T_FAILED=Не вийшло. Надішліть цей текст у підтримку XiaoDroidLink (кнопка «Щось не працює?» у застосунку):"
set "T_OFF=Готово ✓ Усе як було. XiaoDroidLink працює як раніше."
set "T_DIM=Готово ✓ Затемнення екрана вимкнено."
set "T_UNPLUG=Кабель можна від'єднати."
set "T_CLOSE=Натисніть будь-яку клавішу, щоб закрити."

:start
echo.
echo === !T_TITLE! ===
echo.

rem ---------- adb ----------
set "ADB="
where adb >nul 2>nul && set "ADB=adb"
if not defined ADB if exist "%TOOLS%\platform-tools\adb.exe" set "ADB=%TOOLS%\platform-tools\adb.exe"
if not defined ADB (
  echo !T_GETADB!
  if not exist "%TOOLS%" mkdir "%TOOLS%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -UseBasicParsing 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip' -OutFile '%TOOLS%\tools.zip'; Expand-Archive -Force '%TOOLS%\tools.zip' '%TOOLS%'; exit 0 } catch { exit 1 }"
  if errorlevel 1 (
    echo !T_NONET!
    goto finish
  )
  del "%TOOLS%\tools.zip" >nul 2>nul
  set "ADB=%TOOLS%\platform-tools\adb.exe"
)
"!ADB!" start-server >nul 2>nul

rem ---------- phone ----------
echo !T_CONNECT!
set "ASKED=0"
set "STATE="
for /l %%i in (1,1,90) do (
  if not "!STATE!"=="device" (
    set "COUNT=0"
    set "STATE="
    for /f "skip=1 tokens=1,2" %%a in ('"!ADB!" devices') do (
      set /a COUNT+=1
      set "STATE=%%b"
    )
    if !COUNT! gtr 1 (
      echo !T_MANY!
      goto finish
    )
    if "!STATE!"=="unauthorized" if "!ASKED!"=="0" (
      echo !T_ALLOW!
      set "ASKED=1"
    )
    if not "!STATE!"=="device" timeout /t 2 /nobreak >nul
  )
)
if not "!STATE!"=="device" (
  echo.
  echo !T_NOPHONE1!
  echo !T_NOPHONE2!
  echo !T_NOPHONE3!
  echo !T_NOPHONE4!
  goto finish
)
for /f "delims=" %%m in ('"!ADB!" shell getprop ro.product.model ^<nul') do set "MODEL=%%m"
for /f "delims=" %%m in ('"!ADB!" shell getprop ro.product.brand ^<nul') do set "BRAND=%%m"
echo !T_FOUND! !BRAND! !MODEL!

set "HASAPP=0"
for /f "delims=" %%p in ('"!ADB!" shell pm list packages %PKG% ^<nul') do if "%%p"=="package:%PKG%" set "HASAPP=1"
if "!HASAPP!"=="0" (
  echo !T_NOAPP!
  goto finish
)
set "CODE=0"
for /f "tokens=2 delims== " %%c in ('"!ADB!" shell "dumpsys package %PKG% | grep -m1 versionCode" ^<nul') do set "CODE=%%c"

rem ---------- menu ----------
echo.
echo !T_MENU0!
echo !T_MENU1!
echo !T_MENU2!
echo !T_MENU3!
echo !T_MENU4!
set "CHOICE="
set /p "CHOICE=!T_CHOOSE!"
echo.
if "!CHOICE!"=="1" goto turn_on
if "!CHOICE!"=="2" goto turn_off
if "!CHOICE!"=="3" goto dim_off
goto finish

:turn_on
if !CODE! lss %MIN_CODE% (
  echo !T_OLDAPP!
  goto finish
)
"!ADB!" shell appops set %PKG% PROJECT_MEDIA allow <nul > "%TEMP%\xdl-out.txt" 2>&1
"!ADB!" shell pm grant %PKG% android.permission.WRITE_SECURE_SETTINGS <nul >> "%TEMP%\xdl-out.txt" 2>&1
set "OK1=0"
set "OK2=0"
"!ADB!" shell appops get %PKG% PROJECT_MEDIA <nul | findstr /c:"allow" >nul && set "OK1=1"
"!ADB!" shell dumpsys package %PKG% <nul | findstr /c:"WRITE_SECURE_SETTINGS: granted=true" >nul && set "OK2=1"
if "!OK1!!OK2!"=="11" (
  echo !T_ON0!
  echo !T_ON1!
  echo !T_ON2!
  echo !T_ON3!
  echo !T_ON4!
  echo !T_UNPLUG!
  goto finish
)
if "!OK1!"=="1" (
  echo !T_HALF!
  set "B=!BRAND!"
  if /i "!B!"=="xiaomi" set "B=X"
  if /i "!B!"=="redmi" set "B=X"
  if /i "!B!"=="poco" set "B=X"
  if "!B!"=="X" (
    echo.
    echo !T_XIAOMI1!
    echo !T_XIAOMI2!
  )
  goto finish
)
echo !T_FAILED!
echo !BRAND! !MODEL! / !CODE!
type "%TEMP%\xdl-out.txt"
goto finish

:turn_off
"!ADB!" shell settings put secure reduce_bright_colors_activated 0 <nul >nul 2>&1
"!ADB!" shell appops set %PKG% PROJECT_MEDIA ignore <nul >nul 2>&1
"!ADB!" shell pm revoke %PKG% android.permission.WRITE_SECURE_SETTINGS <nul >nul 2>&1
echo !T_OFF!
echo !T_UNPLUG!
goto finish

:dim_off
"!ADB!" shell settings put secure reduce_bright_colors_activated 0 <nul >nul 2>&1
echo !T_DIM!
echo !T_UNPLUG!

:finish
echo.
echo !T_CLOSE!
pause >nul
endlocal
